import esphome.codegen as cg
import esphome.config_validation as cv
from esphome.const import CONF_ID

DEPENDENCIES = ["wifi"]
CODEOWNERS = []

CONF_MAX_PROFILES = "max_profiles"
CONF_STATIC_VALIDATION_TIMEOUT = "static_validation_timeout"
CONF_DHCP_FALLBACK_TIMEOUT = "dhcp_fallback_timeout"
CONF_MAINTENANCE_AP_TIMEOUT = "maintenance_ap_timeout"

tankmonitor_network_ns = cg.esphome_ns.namespace("tankmonitor_network")
TankMonitorNetworkManager = tankmonitor_network_ns.class_(
    "TankMonitorNetworkManager", cg.Component
)

CONFIG_SCHEMA = cv.Schema(
    {
        cv.GenerateID(): cv.declare_id(TankMonitorNetworkManager),
        cv.Optional(CONF_MAX_PROFILES, default=5): cv.int_range(min=1, max=5),
        cv.Optional(
            CONF_STATIC_VALIDATION_TIMEOUT, default="8s"
        ): cv.positive_time_period_milliseconds,
        cv.Optional(
            CONF_DHCP_FALLBACK_TIMEOUT, default="10s"
        ): cv.positive_time_period_milliseconds,
        cv.Optional(
            CONF_MAINTENANCE_AP_TIMEOUT, default="15s"
        ): cv.positive_time_period_milliseconds,
    }
).extend(cv.COMPONENT_SCHEMA)


async def to_code(config):
    # WiFiAP::set_manual_ip() è compilato condizionalmente nel core.
    cg.add_define("USE_WIFI_MANUAL_IP")

    var = cg.new_Pvariable(config[CONF_ID])
    await cg.register_component(var, config)

    cg.add(var.set_max_profiles(config[CONF_MAX_PROFILES]))
    cg.add(
        var.set_static_validation_timeout(
            config[CONF_STATIC_VALIDATION_TIMEOUT].total_milliseconds
        )
    )
    cg.add(
        var.set_dhcp_fallback_timeout(
            config[CONF_DHCP_FALLBACK_TIMEOUT].total_milliseconds
        )
    )
    cg.add(
        var.set_maintenance_ap_timeout(
            config[CONF_MAINTENANCE_AP_TIMEOUT].total_milliseconds
        )
    )
