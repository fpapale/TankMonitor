#pragma once

#include <algorithm>
#include <cstdint>
#include <cstring>
#include <string>

#include "esphome/components/network/ip_address.h"
#include "esphome/components/wifi/wifi_component.h"
#include "esphome/core/component.h"
#include "esphome/core/log.h"
#include "esphome/core/preferences.h"

namespace esphome {
namespace tankmonitor_network {

static const char *const TAG = "tankmonitor_network";

class TankMonitorNetworkManager : public Component {
 public:
  void set_max_profiles(uint8_t value) {
    this->max_profiles_ = std::min<uint8_t>(value, MAX_PROFILES);
  }

  void set_static_validation_timeout(uint32_t value) {
    this->static_validation_timeout_ms_ = value;
  }

  void set_dhcp_fallback_timeout(uint32_t value) {
    this->dhcp_fallback_timeout_ms_ = value;
  }

  void set_maintenance_ap_timeout(uint32_t value) {
    this->maintenance_ap_timeout_ms_ = value;
  }

  float get_setup_priority() const override {
    // WiFi ha enable_on_boot=false: carichiamo i profili dopo il setup
    // del componente WiFi ma prima delle automazioni on_boot.
    return setup_priority::AFTER_WIFI;
  }

  void setup() override {
    this->pref_ = global_preferences->make_preference<StoredConfig>(
        PREF_KEY, true
    );

    if (!this->pref_.load(&this->config_) ||
        this->config_.magic != CONFIG_MAGIC ||
        this->config_.version != CONFIG_VERSION) {
      this->reset_config_();
      ESP_LOGI(TAG, "No TankMonitor network profiles stored");
      // Non tocchiamo le STA del core: in questo modo eventuali
      // credenziali salvate dal captive portal / wifi.configure restano valide.
      return;
    }

    this->sanitize_config_();

    const int pending = this->find_pending_static_();
    if (pending >= 0) {
      this->test_index_ = pending;
      this->test_stage_ = TestStage::STATIC;
      this->rebuild_wifi_profiles_();
      ESP_LOGI(TAG, "Pending static IPv4 test for SSID '%s'",
               this->config_.profiles[pending].ssid);
    } else {
      this->rebuild_wifi_profiles_();
    }
  }

  void loop() override {
    if (this->test_stage_ == TestStage::NONE)
      return;

    auto *wifi = wifi::global_wifi_component;
    if (wifi == nullptr || wifi->is_disabled()) {
      this->attempt_started_ms_ = 0;
      return;
    }

    if (this->attempt_started_ms_ == 0) {
      this->attempt_started_ms_ = millis();
      return;
    }

    const uint32_t elapsed = millis() - this->attempt_started_ms_;

    if (this->test_stage_ == TestStage::STATIC &&
        elapsed >= this->static_validation_timeout_ms_) {
      ESP_LOGW(TAG, "Static IPv4 validation timed out; retrying same SSID with DHCP");
      this->mark_static_failed_before_fallback_();
      this->test_stage_ = TestStage::DHCP;
      this->attempt_started_ms_ = 0;
      this->restart_wifi_for_current_stage_();
      return;
    }

    if (this->test_stage_ == TestStage::DHCP &&
        elapsed >= this->dhcp_fallback_timeout_ms_) {
      ESP_LOGW(TAG, "DHCP fallback test timed out; restoring all known profiles");
      this->test_stage_ = TestStage::NONE;
      this->test_index_ = -1;
      this->attempt_started_ms_ = 0;
      this->restart_wifi_all_profiles_();
    }
  }

  void dump_config() override {
    ESP_LOGCONFIG(TAG, "TankMonitor Network Manager:");
    ESP_LOGCONFIG(TAG, "  Stored profiles: %u", this->profile_count_());
    ESP_LOGCONFIG(TAG, "  Max profiles: %u", this->max_profiles_);
    ESP_LOGCONFIG(TAG, "  Static validation timeout: %u ms",
                  this->static_validation_timeout_ms_);
    ESP_LOGCONFIG(TAG, "  DHCP fallback timeout: %u ms",
                  this->dhcp_fallback_timeout_ms_);
    // Password deliberatamente NON loggate.
  }

  // Chiamato prima di un wake normale: niente AP di setup automatico.
  void prepare_normal() {
    if (wifi::global_wifi_component != nullptr)
      wifi::global_wifi_component->set_ap_timeout(0);
  }

  // Chiamato in maintenance: se le reti note falliscono, il fallback AP
  // parte dopo maintenance_ap_timeout_ms_.
  void prepare_maintenance() {
    if (wifi::global_wifi_component != nullptr)
      wifi::global_wifi_component->set_ap_timeout(
          this->maintenance_ap_timeout_ms_
      );
  }

  bool add_or_update_profile(const std::string &ssid,
                             const std::string &password,
                             int priority) {
    if (ssid.empty() || ssid.size() > 32 || password.size() > 64)
      return false;

    int idx = this->find_profile_(ssid);
    if (idx < 0) {
      idx = this->find_free_slot_();
      if (idx < 0)
        return false;
      std::memset(&this->config_.profiles[idx], 0, sizeof(Profile));
      this->config_.profiles[idx].enabled = 1;
    }

    auto &p = this->config_.profiles[idx];
    copy_string_(p.ssid, sizeof(p.ssid), ssid);
    copy_string_(p.password, sizeof(p.password), password);
    p.priority = static_cast<int8_t>(
        std::max(-100, std::min(100, priority))
    );

    this->save_();
    return true;
  }

  bool remove_profile(const std::string &ssid) {
    const int idx = this->find_profile_(ssid);
    if (idx < 0)
      return false;

    std::memset(&this->config_.profiles[idx], 0, sizeof(Profile));
    this->save_();
    return true;
  }

  bool set_dhcp(const std::string &ssid) {
    const int idx = this->find_profile_(ssid);
    if (idx < 0)
      return false;

    auto &p = this->config_.profiles[idx];
    p.use_static = 0;
    p.static_pending = 0;
    p.static_validated = 0;
    p.static_failed = 0;

    this->save_();
    return true;
  }

  bool set_static(const std::string &ssid,
                  const std::string &static_ip,
                  const std::string &gateway,
                  const std::string &subnet,
                  const std::string &dns1,
                  const std::string &dns2) {
    const int idx = this->find_profile_(ssid);
    if (idx < 0)
      return false;

    if (!valid_required_ip_(static_ip) ||
        !valid_required_ip_(gateway) ||
        !valid_required_ip_(subnet) ||
        !valid_optional_ip_(dns1) ||
        !valid_optional_ip_(dns2)) {
      ESP_LOGW(TAG, "Invalid IPv4 configuration for SSID '%s'", ssid.c_str());
      return false;
    }

    auto &p = this->config_.profiles[idx];
    p.use_static = 1;
    p.static_pending = 1;
    p.static_validated = 0;
    p.static_failed = 0;

    copy_string_(p.static_ip, sizeof(p.static_ip), static_ip);
    copy_string_(p.gateway, sizeof(p.gateway), gateway);
    copy_string_(p.subnet, sizeof(p.subnet), subnet);
    copy_string_(p.dns1, sizeof(p.dns1), dns1);
    copy_string_(p.dns2, sizeof(p.dns2), dns2);

    // Non interrompiamo la sessione corrente.
    // La configurazione verrà testata al prossimo wake/reboot.
    this->save_();
    return true;
  }

  void clear_profiles() {
    this->reset_config_();
    this->save_();

    // Non cancelliamo qui le credenziali interne di ESPHome/captive portal.
    // Il recovery locale resta quindi disponibile.
  }

  void start_scan() {
    auto *wifi = wifi::global_wifi_component;
    if (wifi != nullptr && !wifi->is_disabled())
      wifi->start_scanning();
  }

  // Da chiamare SOLO dopo che Home Assistant è realmente connesso
  // (api.connected state_subscription_only).
  void confirm_backend_connected() {
    auto *wifi = wifi::global_wifi_component;
    if (wifi == nullptr || !wifi->is_connected())
      return;

    this->adopt_current_network_if_needed_();

    if (this->test_stage_ == TestStage::NONE)
      return;

    if (this->test_index_ < 0 || this->test_index_ >= MAX_PROFILES)
      return;

    auto &p = this->config_.profiles[this->test_index_];

    if (this->test_stage_ == TestStage::STATIC) {
      ESP_LOGI(TAG, "Static IPv4 validated for '%s'", p.ssid);
      p.static_pending = 0;
      p.static_validated = 1;
      p.static_failed = 0;
    } else if (this->test_stage_ == TestStage::DHCP) {
      ESP_LOGW(TAG, "DHCP fallback validated for '%s'; static settings retained for editing", p.ssid);
      p.static_pending = 0;
      p.static_validated = 0;
      p.static_failed = 1;
    }

    this->save_();
    this->test_stage_ = TestStage::NONE;
    this->test_index_ = -1;
    this->attempt_started_ms_ = 0;
  }

  bool is_static_fallback_active() const {
    for (uint8_t i = 0; i < this->max_profiles_; i++) {
      const auto &p = this->config_.profiles[i];
      if (p.enabled && p.use_static && p.static_failed)
        return true;
    }
    return false;
  }

  bool has_pending_static() const {
    return this->find_pending_static_() >= 0;
  }

  std::string current_mode() const {
    auto *wifi = wifi::global_wifi_component;
    if (wifi == nullptr || !wifi->is_connected())
      return "OFFLINE";

    const wifi::WiFiAP ap = wifi->get_sta();
    const std::string ssid(ap.get_ssid().c_str());
    const int idx = this->find_profile_(ssid);

    if (idx < 0)
      return "DHCP";

    const auto &p = this->config_.profiles[idx];

    if (p.use_static && p.static_failed)
      return "DHCP_FALLBACK";
    if (p.use_static && (p.static_validated || p.static_pending))
      return "STATIC";

    return "DHCP";
  }

  std::string profile_summary() const {
    std::string out;
    out.reserve(256);

    for (uint8_t i = 0; i < this->max_profiles_; i++) {
      const auto &p = this->config_.profiles[i];
      if (!p.enabled)
        continue;

      if (!out.empty())
        out += " | ";

      out += p.ssid;
      out += " [p=";
      out += std::to_string(static_cast<int>(p.priority));

      if (!p.use_static) {
        out += ",DHCP]";
      } else if (p.static_failed) {
        out += ",DHCP_FALLBACK,static=";
        out += p.static_ip;
        out += "]";
      } else if (p.static_pending) {
        out += ",STATIC_PENDING,";
        out += p.static_ip;
        out += "]";
      } else {
        out += ",STATIC,";
        out += p.static_ip;
        out += "]";
      }
    }

    if (out.empty())
      return "Captive-portal/default WiFi only";

    return out;
  }

 protected:
  static constexpr uint8_t MAX_PROFILES = 5;
  static constexpr uint32_t PREF_KEY = 0x544D4E32;  // "TMN2"
  static constexpr uint32_t CONFIG_MAGIC = 0x544D4E32;
  static constexpr uint16_t CONFIG_VERSION = 1;

  struct Profile {
    uint8_t enabled;
    int8_t priority;

    uint8_t use_static;
    uint8_t static_pending;
    uint8_t static_validated;
    uint8_t static_failed;

    char ssid[33];
    char password[65];

    char static_ip[16];
    char gateway[16];
    char subnet[16];
    char dns1[16];
    char dns2[16];
  };

  struct StoredConfig {
    uint32_t magic;
    uint16_t version;
    uint16_t reserved;
    Profile profiles[MAX_PROFILES];
  };

  enum class TestStage : uint8_t {
    NONE = 0,
    STATIC = 1,
    DHCP = 2,
  };

  ESPPreferenceObject pref_;
  StoredConfig config_{};

  uint8_t max_profiles_{MAX_PROFILES};
  uint32_t static_validation_timeout_ms_{8000};
  uint32_t dhcp_fallback_timeout_ms_{10000};
  uint32_t maintenance_ap_timeout_ms_{15000};

  TestStage test_stage_{TestStage::NONE};
  int8_t test_index_{-1};
  uint32_t attempt_started_ms_{0};

  void reset_config_() {
    std::memset(&this->config_, 0, sizeof(this->config_));
    this->config_.magic = CONFIG_MAGIC;
    this->config_.version = CONFIG_VERSION;
  }

  void sanitize_config_() {
    for (uint8_t i = 0; i < MAX_PROFILES; i++) {
      auto &p = this->config_.profiles[i];
      p.ssid[sizeof(p.ssid) - 1] = '\0';
      p.password[sizeof(p.password) - 1] = '\0';
      p.static_ip[sizeof(p.static_ip) - 1] = '\0';
      p.gateway[sizeof(p.gateway) - 1] = '\0';
      p.subnet[sizeof(p.subnet) - 1] = '\0';
      p.dns1[sizeof(p.dns1) - 1] = '\0';
      p.dns2[sizeof(p.dns2) - 1] = '\0';
    }
  }

  void save_() {
    this->config_.magic = CONFIG_MAGIC;
    this->config_.version = CONFIG_VERSION;

    if (!this->pref_.save(&this->config_))
      ESP_LOGW(TAG, "Failed to save network configuration");
  }

  static void copy_string_(char *dest, size_t size,
                           const std::string &value) {
    if (size == 0)
      return;
    std::strncpy(dest, value.c_str(), size - 1);
    dest[size - 1] = '\0';
  }

  static bool valid_required_ip_(const std::string &value) {
    if (value.empty())
      return false;
    const network::IPAddress ip(value);
    return ip.is_set();
  }

  static bool valid_optional_ip_(const std::string &value) {
    if (value.empty())
      return true;
    const network::IPAddress ip(value);
    return ip.is_set();
  }

  uint8_t profile_count_() const {
    uint8_t count = 0;
    for (uint8_t i = 0; i < this->max_profiles_; i++)
      if (this->config_.profiles[i].enabled)
        count++;
    return count;
  }

  int find_profile_(const std::string &ssid) const {
    for (uint8_t i = 0; i < this->max_profiles_; i++) {
      const auto &p = this->config_.profiles[i];
      if (p.enabled && ssid == p.ssid)
        return i;
    }
    return -1;
  }

  int find_free_slot_() const {
    for (uint8_t i = 0; i < this->max_profiles_; i++)
      if (!this->config_.profiles[i].enabled)
        return i;
    return -1;
  }

  int find_pending_static_() const {
    for (uint8_t i = 0; i < this->max_profiles_; i++) {
      const auto &p = this->config_.profiles[i];
      if (p.enabled && p.use_static &&
          p.static_pending && !p.static_failed)
        return i;
    }
    return -1;
  }

  wifi::WiFiAP make_ap_(const Profile &p, bool force_dhcp) const {
    wifi::WiFiAP ap;
    ap.set_ssid(p.ssid);
    ap.set_password(p.password);
    ap.set_priority(p.priority);

#ifdef USE_WIFI_MANUAL_IP
    if (p.use_static && !p.static_failed && !force_dhcp) {
      wifi::ManualIP manual;
      manual.static_ip = network::IPAddress(p.static_ip);
      manual.gateway = network::IPAddress(p.gateway);
      manual.subnet = network::IPAddress(p.subnet);
      manual.dns1 = p.dns1[0] ? network::IPAddress(p.dns1) : network::IPAddress();
      manual.dns2 = p.dns2[0] ? network::IPAddress(p.dns2) : network::IPAddress();
      ap.set_manual_ip(manual);
    }
#endif

    return ap;
  }

  void rebuild_wifi_profiles_() {
    auto *wifi = wifi::global_wifi_component;
    if (wifi == nullptr)
      return;

    // Durante un test STATIC/DHCP proviamo intenzionalmente solo
    // il profilo interessato, così il risultato non è ambiguo.
    if (this->test_stage_ != TestStage::NONE &&
        this->test_index_ >= 0 &&
        this->test_index_ < this->max_profiles_) {
      const auto &p = this->config_.profiles[this->test_index_];
      if (p.enabled) {
        wifi->clear_sta();
        wifi->init_sta(1);
        wifi->add_sta(this->make_ap_(
            p, this->test_stage_ == TestStage::DHCP
        ));
      }
      return;
    }

    const uint8_t count = this->profile_count_();

    // Se non abbiamo profili nostri NON cancelliamo la STA eventualmente
    // salvata dal captive portal/wifi.configure.
    if (count == 0)
      return;

    wifi->clear_sta();
    wifi->init_sta(count);

    for (uint8_t i = 0; i < this->max_profiles_; i++) {
      const auto &p = this->config_.profiles[i];
      if (!p.enabled)
        continue;
      wifi->add_sta(this->make_ap_(p, false));
    }
  }

  void restart_wifi_for_current_stage_() {
    auto *wifi = wifi::global_wifi_component;
    if (wifi == nullptr)
      return;

    wifi->disable();

    this->set_timeout("tm_net_restart", 250, [this]() {
      this->rebuild_wifi_profiles_();
      if (wifi::global_wifi_component != nullptr)
        wifi::global_wifi_component->enable();
    });
  }

  void restart_wifi_all_profiles_() {
    auto *wifi = wifi::global_wifi_component;
    if (wifi == nullptr)
      return;

    wifi->disable();

    this->set_timeout("tm_net_restart_all", 250, [this]() {
      this->rebuild_wifi_profiles_();
      if (wifi::global_wifi_component != nullptr)
        wifi::global_wifi_component->enable();
    });
  }

  void mark_static_failed_before_fallback_() {
    if (this->test_index_ < 0 ||
        this->test_index_ >= this->max_profiles_)
      return;

    auto &p = this->config_.profiles[this->test_index_];
    p.static_pending = 0;
    p.static_validated = 0;
    p.static_failed = 1;

    // Salviamo PRIMA del tentativo DHCP: anche un power-loss non
    // farà rientrare il nodo in un loop con lo static IP rotto.
    this->save_();
  }

  void adopt_current_network_if_needed_() {
    auto *wifi = wifi::global_wifi_component;
    if (wifi == nullptr || !wifi->is_connected())
      return;

    const wifi::WiFiAP current = wifi->get_sta();
    const std::string ssid(current.get_ssid().c_str());

    if (ssid.empty() || this->find_profile_(ssid) >= 0)
      return;

    const std::string password(current.get_password().c_str());

    if (this->find_free_slot_() < 0)
      return;

    if (this->add_or_update_profile(ssid, password, 0)) {
      ESP_LOGI(TAG,
               "Adopted captive-portal/runtime WiFi '%s' into TankMonitor profiles",
               ssid.c_str());
    }
  }
};

}  // namespace tankmonitor_network
}  // namespace esphome
